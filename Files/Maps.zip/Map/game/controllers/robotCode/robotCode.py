from smarthome_utils.U14Robot import U14Robot
import random

#Initialize the Robot
robot = U14Robot("Kavosh") #Set robot's team's name
turn = 0 #1.Backward - 2.Random turning
duration = 0 #Duration of performance

#Main Control Loop
while robot.step()!= -1:
    robot.debug_print() #Show Robot Sensors on terminal
    random_number = random.randint(1, 2) #Generate random integer number between 1, 2

    #if Duration is positive subtract one unit and execute previous statement values
    if duration > 0:
        duration = duration - 1
    #Avoiding obstacle
    #Backward
    elif turn == 0 and robot.Front < 50:
        robot.move(-10, -10)
        duration = 15
        turn = 1
    #Random turning
    elif turn == 1:
        if random_number == 1:
            robot.move(10, -10)
        else:
            robot.move(-10, 10)
        duration = 15
        turn = 0
    #Move
    else:
        robot.move(10, 10)
