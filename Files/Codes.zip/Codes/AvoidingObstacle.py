from smarthome_utils.U14Robot import U14Robot

#Initialize the Robot
robot = U14Robot("Kavosh") #Set robot's team's name 

#Main Control Loop
while robot.step()!= -1:
    robot.debug_print() #Show Robot Sensors on terminal

    #Avoiding obstacle
    if robot.FrontRight < 50 or robot.FrontLeft < 50:
        robot.move(10, -10)

    #Otherwise continue as before 
    else:
        robot.move(10, 10)