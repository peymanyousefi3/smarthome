from smarthome_utils.U14Robot import U14Robot
import random

#Initialize the Robot
robot = U14Robot("Kavosh") #Set robot's team's name

#Main Control Loop
while robot.step()!= -1:
    robot.debug_print() #Show Robot Sensors on terminal
    random_number = random.randint(1, 3) #Generate random integer number between 1, 3

    #Avoiding obstacle
    if robot.FrontLeft < 50 or robot.FrontRight < 50:
        robot.move(10, -10)

    #Random movement    
    else:
        if random_number == 1:
            robot.move(10, 10)
        elif random_number == 2:
            robot.move(10, 3)
        elif random_number == 3:
            robot.move(7, 9)