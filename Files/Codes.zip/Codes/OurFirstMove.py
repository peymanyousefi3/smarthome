from smarthome_utils.U14Robot import U14Robot

#Initialize the Robot
robot = U14Robot("Kavosh") #Set robot's team name 

#Main Control Loop
while robot.step()!= -1:

    robot.move(10, 10) # move(WheelLeft, WheelRight)